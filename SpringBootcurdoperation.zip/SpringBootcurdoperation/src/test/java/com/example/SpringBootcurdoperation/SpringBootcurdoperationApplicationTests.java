package com.example.SpringBootcurdoperation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootcurdoperationApplicationTests {

	@Test
	void contextLoads() {
	}

}
