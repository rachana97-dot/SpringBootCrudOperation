package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.student;
import com.example.repository.studrepository;


@Service
public class studservice {
	@Autowired
	public studrepository repo;
	
	public Iterable<student>listAll()
	{
	return this.repo.findAll();
	}

}
