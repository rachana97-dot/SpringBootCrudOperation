package com.example.SpringBootcurdoperation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class SpringBootcurdoperationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootcurdoperationApplication.class, args);
	}

}
